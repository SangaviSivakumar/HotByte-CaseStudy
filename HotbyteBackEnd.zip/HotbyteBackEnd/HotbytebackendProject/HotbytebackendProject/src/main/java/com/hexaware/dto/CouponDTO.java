package com.hexaware.dto;

import java.time.LocalDate;
import java.util.Date;

import com.hexaware.enums.CouponStatus;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CouponDTO {
	private Long couponId;
    private String name;
    private String code;
    private String description;
    private Integer discount;        
    private Double minOrder;
    private Double maxDiscount;
    private Integer usageLimit;
    private Integer usageCount;          
    private LocalDate expiry;
    private CouponStatus status; 

}
